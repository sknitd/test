//Suppose a file contains Cricket Player name of cricketer, his age, number of 
//test  matches  that he has  played and the average  runs  that he has scored in 
//each test match. Create an array of objects to hold records of 20 such cricketer 
//and then write a program to read these records and arrange them in ascending 
//order by average runs. 


package assignment7;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;


public class Assignment7Main
{

	 public static void main(String[] args) throws IOException {
		 ArrayList<String> rows = new ArrayList<String>();
		    BufferedReader reader = new BufferedReader(new FileReader("CricketPlayer.csv"));
		    String s;
		    while((s = reader.readLine())!=null)
		    {
		    	rows.add(s);
		    }
		    reader.close();
		    String playersdata[][]= new String[rows.size()][4];
		    CricketPlayer c[]= new CricketPlayer[rows.size()];
		    int temp1,temp2;
		    float temp3;
		    for (int i = 0; i < rows.size(); i++)
		    {
				playersdata[i]=rows.get(i).split(",");
				temp1=Integer.parseInt(playersdata[i][1].trim());
				temp2=Integer.parseInt(playersdata[i][2].trim());
				temp3=Float.parseFloat(playersdata[i][3].trim());
				c[i]= new CricketPlayer(playersdata[i][0], temp1,temp2,temp3);
			}
		    Arrays.sort(c,new Comparator<CricketPlayer>(){  
		        @Override  
		        public int compare(CricketPlayer p1, CricketPlayer p2){ 
		        	if(p1.getAverage()>p2.getAverage())
		             return 1;
		        	else 
		        		return -1;
		       }  
		    } );
		    
		    for(int i=0;i<c.length;i++)
		    {
		    	System.out.println(c[i].name+" "+c[i].age+" "+c[i].testMatches+" "+c[i].getAverage());
		    }
		    
		    
	}
}
