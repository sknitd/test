package recharge;

import java.util.HashMap;

public class Vodafone implements PayTM
{
	private final HashMap<Integer, Float> plans = new HashMap<Integer,Float>();

	private void initializePlans() 
	{
		plans.put(10, 7f);
		plans.put(20, 10f);
		plans.put(50, 40.5f);
		plans.put(100, 75.4f);
		plans.put(150, 142f);
	}
	
@Override
public void denominations() 
{
	initializePlans();
	System.out.println("The available plans for Vodafone are (Recharge=Talktime):");
	System.out.println(plans.toString()+"\n");
	
	
}
@Override
public void recharge(long mob, int amt)
{
	if(!plans.containsKey(amt))
	{
		
		new InvalidAmountException("No JIO plans available for this amount");
	}

	
	
	if(customer.containsKey(mob))
	{
		float balance= (float) customer.get(mob);
		balance+=plans.get(amt);
		customer.put(mob, balance);
	}
	else
	{
		customer.put(mob, plans.get(amt));
	}
	System.out.println("Recharge of Rs"+amt +" for your Vodafone account done");
	System.out.println("Current balance is Rs"+customer.get(mob));
	
}

}
