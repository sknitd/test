package recharge;

import java.util.HashMap;
import recharge.InvalidAmountException;

public class Jio implements PayTM {

		private final HashMap<Integer, Float> plans = new HashMap<Integer,Float>();

		private void initializePlans() 
		{
			plans.put(10, 12f);
			plans.put(20, 25f);
			plans.put(50, 55f);
			plans.put(100, 120f);
			plans.put(150, 250f);
		}
		
	@Override
	public void denominations() 
	{
		initializePlans();
		System.out.println("The available plans for Jio are (Recharge=Talktime):");
		System.out.println(plans.toString()+"\n");
		
		
	}

	@Override
	public void recharge(long mob, int amt) throws InvalidAmountException
	{
		if(!plans.containsKey(amt))
		{
			
				throw new InvalidAmountException("No JIO plans available for this amount");
			
		}
		
		
		if(customer.containsKey(mob))
		{
			float balance= customer.get(mob);
			balance+=plans.get(amt);
			customer.put(mob, balance);
		}
		else
		{
			customer.put(mob, plans.get(amt));
		}
		System.out.println("Recharge of Rs"+amt +" for your Jio account is done");
		System.out.println("Current balance is Rs"+customer.get(mob));
		
	}

}
