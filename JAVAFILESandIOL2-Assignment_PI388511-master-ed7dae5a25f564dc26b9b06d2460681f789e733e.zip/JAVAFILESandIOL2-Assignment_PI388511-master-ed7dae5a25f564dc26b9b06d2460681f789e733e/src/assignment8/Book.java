package assignment8;

public class Book
{
	public int getAccessionNo() {
		return AccessionNo;
	}

	public void setAccessionNo(int accessionNo) {
		AccessionNo = accessionNo;
	}

	int SNo;
	String Name,Title,Author;
	int AccessionNo;
	
	public int getSNo() {
		return SNo;
	}

	public void setSNo(int sNo) {
		SNo = sNo;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public void displayBooksinfo()
	{
		System.out.println(SNo+" "+Name+" "+Title+" "+Author+" "+AccessionNo);
	}
}
