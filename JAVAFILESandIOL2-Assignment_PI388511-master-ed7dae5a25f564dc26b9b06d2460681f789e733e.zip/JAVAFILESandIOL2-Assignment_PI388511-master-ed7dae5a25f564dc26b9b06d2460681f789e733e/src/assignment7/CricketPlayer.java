package assignment7;

public class CricketPlayer
{
	String name;
	int age,testMatches;
	float average;
	public CricketPlayer(String name, int age, int testMatches, float average)
	{
		super();
		this.name = name;
		this.age = age;
		this.testMatches = testMatches;
		this.average = average;
		
	}
	public float getAverage()
	{
		return average;
	}
	public void setAverage(float average)
	{
		this.average = average;
	}

}