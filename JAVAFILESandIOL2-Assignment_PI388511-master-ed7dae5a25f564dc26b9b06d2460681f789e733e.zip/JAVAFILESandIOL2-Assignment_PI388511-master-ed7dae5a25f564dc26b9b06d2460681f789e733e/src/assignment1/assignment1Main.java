//Suppose a file contains Employee’s records with each record containing name,
//address and age of Employee. Write a program to read these records and
//display them in sorted order by name

package assignment1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class assignment1Main {

	public static void main(String[] args) throws IOException
	{
	    ArrayList<String> rows = new ArrayList<String>();
	    BufferedReader reader = new BufferedReader(new FileReader("employees.txt"));

	    String s;
	    while((s = reader.readLine())!=null)
	    {
	    	rows.add(s);
	    }
	    Collections.sort(rows);
	    reader.close();
	    for(String str:rows)
	    {
	    	System.out.println(str);
	    }
	}
}
