//Write a Client Application will consists of following methods
//(a)Write a method to print names of all students who joined in a particular 
//year. 
//(b)Write a method to print the data of a student whose roll number is given. 

package assignment10;

import java.util.List;
import java.util.Scanner;

public class Assignment10Main
{

	public static void getNamesbyYear(int year)
	{
		
		List<Student> students = StudentDataReader1.bookFileReader1();
		for(int i=0;i<students.size();i++)
		{
			if(students.get(i).getYearofjoining()==year)
			{
				System.out.println(students.get(i).getName());
			}
		}
	}
	
	public static void getDatabyRoll(int rollnumber)
	{
		List<Student> students = StudentDataReader1.bookFileReader1();
		for(int i=0;i<students.size();i++)
		{
			if(students.get(i).getRollnumber()==rollnumber)
			{
				System.out.println("Name: "+students.get(i).getName());
				System.out.println("Department: "+students.get(i).getDepartment());
				System.out.println("Course: "+students.get(i).getCourse());
				System.out.println("Year Of Joining: "+students.get(i).getYearofjoining());
			}
		}
	}
	
	public static void main(String[] args)
	{
		
		System.out.println("Which years' students you want?");
		Scanner sc= new Scanner(System.in);
		getNamesbyYear(sc.nextInt());
		while(!sc.hasNext());
		getDatabyRoll(sc.nextInt());
		
		sc.close();
	}

}
