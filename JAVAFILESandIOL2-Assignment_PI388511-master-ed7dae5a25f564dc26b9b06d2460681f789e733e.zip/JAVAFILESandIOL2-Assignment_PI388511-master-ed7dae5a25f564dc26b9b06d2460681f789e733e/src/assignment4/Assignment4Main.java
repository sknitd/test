//Given a text file, write a program to create another text
//file deleting the words “a”, “the”, “an” and
//replacing each one of them with a blank space
package assignment4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Assignment4Main
{
	public static void main(String[] args) throws IOException
	{
		 ArrayList<String> rows = new ArrayList<String>();
		    BufferedReader reader = new BufferedReader(new FileReader("sentences.txt"));

		    String s;
		    while((s = reader.readLine())!=null)
		        rows.add(s);

		    for (int i =0;i<rows.size();i++) 
		    {
				rows.set(i, rows.get(i).replaceAll("a ", " ").replaceAll("an ", " ").replaceAll("the "," ").replaceAll("A ", " ").replaceAll("An ", " ").replaceAll("The "," "));
			}

		    FileWriter writer = new FileWriter("shortsentences.txt");
		    for(String cur: rows)
		    { writer.write(cur+"\n");}

		    reader.close();
		    writer.close();
	}
}
