package recharge;

import java.util.HashMap;

public interface PayTM {
	void recharge(long mobileNumber, int amt) throws InvalidAmountException;

	void denominations();
	static HashMap<Long, Float> customer = new HashMap<Long, Float>();
}
