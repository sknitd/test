package assignment9;

public class Book1
{

	private int bookID,bookStatus;  //bookStatus is 0 for not issued and 1 for issued
	private String bookName,bookAutho;
	private float price;
	public int getBookID() {
		return bookID;
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public int getBookStatus() {
		return bookStatus;
	}
	public void setBookStatus(int bookStatus) {
		this.bookStatus = bookStatus;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAutho() {
		return bookAutho;
	}
	public void setBookAutho(String bookAutho) {
		this.bookAutho = bookAutho;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}

	
}
