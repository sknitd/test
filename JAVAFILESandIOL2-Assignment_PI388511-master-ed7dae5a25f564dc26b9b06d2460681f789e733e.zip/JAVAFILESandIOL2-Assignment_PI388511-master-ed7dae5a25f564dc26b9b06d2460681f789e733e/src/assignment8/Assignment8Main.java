//Write a menu driven program that depicts the working of a library. The menu
//options should be:
//1. Add book information
//2. Display book information
//3. List all books of given author
//4. List the title of specified book
//5. List the count of books in the library
//6. List the books in the order of accession number 

package assignment8;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


public class Assignment8Main
{
	public static List<Book> booksCreator()
	{
		String str=BookFileReader.bookFileReader();
		String temp1[]=str.split("\n");
		int numberOfBooks=temp1.length;
		List<Book> books = new ArrayList<Book>(); 
		for(int i =0; i<numberOfBooks;i++)
		{	
			String temp[]= temp1[i].split(",");
			Book b1= new Book();
			b1.setSNo(Integer.parseInt(temp[0]));
			b1.setName(temp[1]);
			b1.setTitle(temp[2]);
			b1.setAuthor(temp[3]);
			b1.setAccessionNo(Integer.parseInt(temp[4]));
			books.add(b1);
		}
		return books;
	}
	
	public static void displayBook(List<Book> books)
	{
		System.out.println("\nBook Info:");
		System.out.format("%-5s%-20s%-30s%-30s%-15s\n","S.No.","Name","Title","Author","AccessionNo");
		for(int i=0;i<books.size();i++)
		{
			System.out.format("%-5d%-20s%-30s%-30s%-15d\n",books.get(i).getSNo(),books.get(i).getName(),books.get(i).getTitle(),books.get(i).getAuthor(),books.get(i).getAccessionNo());
		}
		System.out.println("\n");
	}
	
	public static void main(String[] args) throws IOException
	{
		System.out.println("\nWelcome to our onilne library:");
		Scanner sc= new Scanner(System.in);
		int key;
			System.out.println("1. Add book information");
			System.out.println("2. Display book information");
			System.out.println("3. List all books of given author");
			System.out.println("4. List the title of specified book");
			System.out.println("5. List the count of books in the library");
			System.out.println("6. List the books in the order of accession number");
			System.out.println("7. Exit\n");
			
			List<Book> books =booksCreator();
			key=Integer.parseInt(sc.nextLine());
			
			switch (key) {
			case 1:				
				Book b2=new Book();
				int length=books.size();
				System.out.println(books.get(length-1).getSNo()+1);
				b2.setSNo(books.get(length-1).getSNo()+1);
				System.out.println("Enter the Book Name");
				b2.setName(sc.nextLine());
				System.out.println("Enter the title of the book");
				b2.setTitle(sc.nextLine());
				System.out.println("Enter the author of the book");
				b2.setAuthor(sc.nextLine());
				b2.setAccessionNo(books.get(length-1).getAccessionNo()+1);
				books.add(b2);
				BookFileWriter.bookFileWriter(b2);
				System.out.println("\nBook is added ");
				displayBook(books);
				break;
				
			case 2:
			
				displayBook(books);
			
				
				break;
			
			case 3:
			{
				System.out.println("Whose book you need?");
				String author=sc.nextLine();
				Book b1= new Book();
				for(int i=0;i<books.size();i++)
				{
					b1=books.get(i);
					if(b1.getAuthor().equalsIgnoreCase(author))
					{
						System.out.println(b1.getTitle());
					}				
				}
				System.out.println("\n");
			}
				
				break;
			case 4:
			{
				System.out.println("Which book do you need?");
				String name=sc.nextLine();
				Book b1= new Book();
				for(int i=0;i<books.size();i++)
				{
					b1=books.get(i);
					if(b1.getName().equalsIgnoreCase(name))
					{
						System.out.println(b1.getTitle());
						break;
					}					
				}
				System.out.println("\n");
			}
				
				break;
			case 5:
			{
				System.out.println("The total number of books are:");
				System.out.println(books.size()+"\n");
			}
				
				break;
				
			case 6:
			{
				 Collections.sort(books, new Comparator<Book>() {

				        public int compare(Book b1, Book b2) {
				        	if(b1.getAccessionNo()>b2.getAccessionNo())
					             return 1;
					        	else 
					        		return -1;
				        }
				    });
				
				
				System.out.println("Book Info sorted with Accession number:");
				System.out.format("%-5s%-20s%-30s%-30s%-15s\n","S.No.","Name","Title","Author","AccessionNo");
				for(int i=0;i<books.size();i++)
				{
					Book b1= new Book();
					b1= books.get(i);
					System.out.format("%-5d%-20s%-30s%-30s%-15d\n",b1.getSNo(),b1.getName(),b1.getTitle(),b1.getAuthor(),b1.getAccessionNo());
				}
				
			}
				break;
			case 7:
			{
				System.exit(0);
			}

			default:
				break;
			}
			
		}
	}

