package recharge;

import java.util.HashMap;

public class Idea implements PayTM {

	
	private final HashMap<Integer, Float> plans = new HashMap<Integer,Float>();

	private void initializePlans() 
	{
		plans.put(10, 7.5f);
		plans.put(20, 15f);
		plans.put(50, 42.5f);
		plans.put(100, 81.4f);
		plans.put(150, 150f);
	}
	
@Override
public void denominations() 
{
	initializePlans();
	System.out.println("The available plans for Idea are (Recharge=Talktime):");
	System.out.println(plans.toString()+"\n");
	
	
}

@Override
public void recharge(long mob, int amt)
{
	if(!plans.containsKey(amt))
	{
		try {
			throw new InvalidAmountException("No Idea plans available for this amount");
		} catch (InvalidAmountException e) {
		}
	}
	
	
	if(customer.containsKey(mob))
	{
		float balance= customer.get(mob);
		balance+=plans.get(amt);
		customer.put(mob, balance);
	}
	else
	{
		customer.put(mob, plans.get(amt));
	}
	System.out.println("\nRecharge of Rs"+amt +" for your Idea account is done");
	System.out.println("Current balance is "+"Rs"+customer.get(mob));
	
}

}
