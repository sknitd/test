package assignment10;

//can be used to write and change parameters

import java.io.FileWriter;
import java.io.IOException;

public class StudentDataWriter1
{
		   public static void bookFileWriter1(Student s1) throws IOException
		   {
			   
			   FileWriter fileWriter = new FileWriter("students.csv",true);
			   
	                fileWriter.append(String.valueOf(s1.getRollnumber()));
	                fileWriter.append(",");
	                fileWriter.append(s1.getName());
	                fileWriter.append(",");
	                fileWriter.append(s1.getDepartment());
	                fileWriter.append(",");
	                fileWriter.append(s1.getCourse());
	                fileWriter.append(",");
	                fileWriter.append(String.valueOf(s1.getYearofjoining()));
	                fileWriter.append("\n");
	                fileWriter.flush();
	                fileWriter.close();
	            
	            System.out.println("CSV file was modified successfully !!!");
		   }
}

