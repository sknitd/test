//Write a program to read the file and print a list of all blood donors whose age 
//is below 25 and blood is type 2. 

package assignment6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Assignment6Main
{
	public static String donor(String sentence)
	{
		String arr[] =sentence.split(",");
		if((Integer.parseInt(arr[2].trim())<25)&&(arr[3].equals("2")))
				{
					return arr[0];
				}
			else 
		return "";
	}
	
	public static void main(String[] args) throws IOException
	{
		
		 ArrayList<String> rows = new ArrayList<String>();
		    BufferedReader reader = new BufferedReader(new FileReader("hospital.csv"));

		    String s;
		    while((s = reader.readLine())!=null)
		        rows.add(s);
		    
		    System.out.println("list of all blood donors whose age is below 25 and blood is type 2 :");
		    String temp;
		    for (int i =0;i<rows.size();i++) 
		    {
		    	temp=donor(rows.get(i));
		    	if(temp.equals(""))
		    	{
		    	}
		    	else
		    	System.out.println(temp);
			}
		    

		    reader.close();
	}
}
