package recharge;


import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

import sun.reflect.Reflection;

public class TestPayTM implements PayTM {

	static Scanner sc = new Scanner(System.in);
	
	public static void TestImplementation
	()
	{	
		
		//Welcome message and purpose
		System.out.println("Welcome to PayTM");
		
		while(true)
		{
			System.out.println("\nWhat do you want to do?");
			System.out.println("1.Know your balance");
			System.out.println("2.Recharge your account");
			System.out.println("3.Exit from the app\n");
			int i=sc.nextInt();
		if(i==1)
		{
			System.out.println("\nEnter Your Mobile Number:");
			long mob=sc.nextLong();
			if(customer.containsKey(mob))
			{System.out.println("Your account balance is: "+customer.get(mob)+"\n");}
			else
			{System.out.println("Invalid number");}
		}
		else if(i==2)
		{
			
		
		
		supportedNw();
		
		PayTM m1 =careerObjects();
		//Getting the phone number
				System.out.println("Plese enter your 10 digit mobile number:");
				long mobileNumber=0;
				while(true)
				{	
					try {
						
						mobileNumber = sc.nextLong();
						if((Long.valueOf(mobileNumber).toString().length())==10)
						{
							break;
						}
						else
							System.out.println("Enter a valid 10 digit mobile number: ");
						//sc.reset();
						//sc.nextLine();
					}
					catch (Exception c) 
					{
						
						System.out.println("Enter a valid 10 digit mobile number: ");
						
					}
					
				
					
				}
				
				
				//calling methods to recharge
				m1.denominations();
				System.out.println("Enter the amount:    ");
				try {
					m1.recharge(mobileNumber, sc.nextInt());
				} catch (InvalidAmountException e) {
				}
				
		}
		else if(i==3)
		{
			System.out.println("Thank You for using PayTM!");
			System.exit(0);
		}
		else
		{
			System.out.println("Enter a valid input");
		}
	}
	}
	
	private static PayTM careerObjects()
	{
		//Creating Objects 
		
		PayTM m1;
		while(true)
		{
			System.out.println("Please enter your Telecom Operator:");
			String telecom = sc.next();
		
			if(telecom.equalsIgnoreCase("Airtel"))
		{
			m1= new Airtel();
			break;
		}
		
		if(telecom.equalsIgnoreCase("Idea"))
		{
			m1 = new Idea();
			break;
		}
		
		else if(telecom.equalsIgnoreCase("Vodafone"))
		{
			m1 = new Vodafone();
			break;
		}
		
		else if(telecom.equalsIgnoreCase("Jio"))
		{
			m1 = new Jio();
			break;
		}
		
		else
		{
			System.out.println("We currently do not support this operator");
		}
		}
		return m1;
	}
	
	public static void supportedNw()
	{
		System.out.println("We currently support Airtel, Idea, Jio, Vodafone\n");
	}
	
	public static void main(String[] args) 
	{
		
		TestImplementation();
		
		
	}

	@Override
	public void recharge(long mobileNumber, int amt) throws InvalidAmountException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void denominations() {
		// TODO Auto-generated method stub
		
	}
}
	
