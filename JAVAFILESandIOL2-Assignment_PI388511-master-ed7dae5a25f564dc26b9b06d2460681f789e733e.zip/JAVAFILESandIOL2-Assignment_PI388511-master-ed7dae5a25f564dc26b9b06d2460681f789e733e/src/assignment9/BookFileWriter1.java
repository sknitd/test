package assignment9;

//can be used to write and change parameters

import java.io.FileWriter;
import java.io.IOException;

public class BookFileWriter1
{
		   public static void bookFileWriter1(Book1 b1) throws IOException
		   {
			   
			   FileWriter fileWriter = new FileWriter("fileofbooks.csv",true);
			   
	                fileWriter.append(String.valueOf(b1.getBookID()));
	                fileWriter.append(",");
	                fileWriter.append(b1.getBookName());
	                fileWriter.append(",");
	                fileWriter.append(b1.getBookAutho());
	                fileWriter.append(",");
	                fileWriter.append(String.valueOf(b1.getPrice()));
	                fileWriter.append(",");
	                fileWriter.append(String.valueOf(b1.getBookStatus()));
	                fileWriter.append("\n");
	                fileWriter.flush();
	                fileWriter.close();
	            
	            System.out.println("CSV file was modified successfully !!!");
		   }
}

