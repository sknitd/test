package assignment8;

import java.io.FileWriter;
import java.io.IOException;

public class BookFileWriter
{
		   public static void bookFileWriter(Book b1) throws IOException
		   {
			   
			   FileWriter fileWriter = new FileWriter("library.csv",true);
			   
	                fileWriter.append(String.valueOf(b1.getSNo()));
	                fileWriter.append(",");
	                fileWriter.append(b1.getName());
	                fileWriter.append(",");
	                fileWriter.append(b1.getTitle());
	                fileWriter.append(",");
	                fileWriter.append(b1.getAuthor());
	                fileWriter.append(",");
	                fileWriter.append(String.valueOf(b1.getAccessionNo()));
	                fileWriter.append("\n");
	                fileWriter.flush();
	                fileWriter.close();
	            
	            System.out.println("CSV file was modified successfully !!!");
		   }
}

