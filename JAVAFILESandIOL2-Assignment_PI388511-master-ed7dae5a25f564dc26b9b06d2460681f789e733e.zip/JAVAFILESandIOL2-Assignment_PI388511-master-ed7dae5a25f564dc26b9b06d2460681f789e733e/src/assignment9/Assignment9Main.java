package assignment9;

public class Assignment9Main
{

	public static void main(String[] args)
	{
		library library1= new library();
		library1.librarylist();
	}

}
