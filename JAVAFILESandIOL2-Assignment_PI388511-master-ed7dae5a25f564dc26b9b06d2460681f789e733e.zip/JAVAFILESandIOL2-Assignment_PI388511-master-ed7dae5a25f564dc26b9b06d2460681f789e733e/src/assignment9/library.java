package assignment9;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class library
{
	List<Book1> books =booksStringCreator();
	public static void displayBook(List<Book1> books)
	{
		System.out.println("\nBook Info:");
		System.out.format("%-5s%-20s%-30s%-30s%-15s\n","bookID","bookName","bookAuthor","Price","Book Status");
		for(int i=0;i<books.size();i++)
		{
			System.out.format("%-5d%-20s%-30s%-30f%-15d\n",books.get(i).getBookID(),books.get(i).getBookName(),books.get(i).getBookAutho(),books.get(i).getPrice(),books.get(i).getBookStatus());
		}
		System.out.println("\n");
	}
	public static List<Book1> booksStringCreator()
	{
		String str=BookFileReader1.bookFileReader1();
		String temp1[]=str.split("\n");
		int numberOfBooks=temp1.length;
		List<Book1> books = new ArrayList<Book1>(); 
		for(int i =0; i<numberOfBooks;i++)
		{	
			String temp[]= temp1[i].split(",");
			Book1 b1= new Book1();
			b1.setBookID(Integer.parseInt(temp[0]));
			b1.setBookName(temp[1]);;
			b1.setBookAutho(temp[2]);
			b1.setPrice(Float.valueOf(temp[3]));
			b1.setBookStatus(Integer.parseInt(temp[4]));  //bookStatus is 0 for not issued and 1 for issued
			books.add(b1);
		}
		return books;
	}
	public void librarylist()
	{
		
		booksStringCreator();
		displayBook(books);
	}
	public void newList() throws IOException
	{
		Scanner sc= new Scanner(System.in);
		Book1 b2=new Book1();
		System.out.println("Enter the Book ID");
		b2.setBookID(sc.nextInt());
		System.out.println("Enter the Book Name");
		b2.setBookName(sc.nextLine());
		System.out.println("Enter the author of the book");
		b2.setBookAutho(sc.nextLine());
		System.out.println("Enter the price of the book");
		b2.setPrice(sc.nextFloat());
		System.out.println("Enter the Book status");
		b2.setBookStatus(sc.nextInt());		
		books.add(b2);
		BookFileWriter1.bookFileWriter1(b2);
		System.out.println("\nBook is added ");
		sc.close();
	}
}
