//Write a program to carry out the following: 
//-To read a text file “TRIAL.TXT” consisting of a maximum of 50 lines of 
//text, each line with   a maximum of 80 characters. 
//-Count and display the number of words contained in the file. 
//-Display the total number of four letter words in the text file. 
//Assume that the end of a word may be a space, comma or a full
//stop followed 
//by one or more spaces or a newline character.

package assignment5;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Assignment5Main
{
	static int fourWordCount=0;
	public static int wordCounter(String str)
	{
		String temp[] = str.split("[ \\.\\,]");
		for(int i=0; i<temp.length;i++)
		{
			if(temp[i].length()==4)
			{
				fourWordCount++;
			}
		}
		return temp.length;
	}

	
	public static void main(String[] args) throws IOException
	{
		ArrayList<String> rows = new ArrayList<String>();
		    BufferedReader reader = new BufferedReader(new FileReader("TRIAL.txt"));

		    String s;
		    while((s = reader.readLine())!=null)
		        {rows.add(s);}
		    int totalWords=0;
		    for (int i =0;i<rows.size();i++) 
		    {
		    	totalWords+=wordCounter(rows.get(i));
			}		    
		    reader.close();
		    System.out.println("Total number of words are :"+totalWords);
		    System.out.println("Four letter words are :"+fourWordCount);
	}

}
