package assignment10;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StudentDataReader1
{
	public static List<Student> bookFileReader1()
	{
		StringBuilder contentBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader("students.csv")))
        {
 
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null)
            {
                contentBuilder.append(sCurrentLine).append("\n");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
		
		String str=contentBuilder.toString();
		String temp1[]=str.split("\n");
		int numberOfBooks=temp1.length;
		List<Student> students = new ArrayList<Student>(); 
		for(int i =0; i<numberOfBooks;i++)
		{	
			String temp[]= temp1[i].split(",");
			Student b1=new Student();
			b1.setRollnumber(Integer.parseInt(temp[0]));
			b1.setName(temp[1]);;
			b1.setDepartment(temp[2]);;
			b1.setCourse(temp[3]);;
			b1.setYearofjoining(Integer.parseInt(temp[4]));;
			students.add(b1);
		}
		return students;
	}
}
