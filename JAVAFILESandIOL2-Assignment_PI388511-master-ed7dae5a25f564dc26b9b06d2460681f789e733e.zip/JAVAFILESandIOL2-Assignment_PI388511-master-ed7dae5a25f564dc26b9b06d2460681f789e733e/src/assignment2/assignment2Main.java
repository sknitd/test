//Write a program to copy one file (employees.txt) to another (employeedata.txt). While doing so replace all
//lowercase characters to their equivalent uppercase characters. 

package assignment2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class assignment2Main 
{
	public static void main(String[] args) throws IOException
	{
		   ArrayList<String> rows = new ArrayList<String>();
		    BufferedReader reader = new BufferedReader(new FileReader("employees.txt"));

		    String s;
		    while((s = reader.readLine())!=null)
		        rows.add(s);

		    for (int i =0;i<rows.size();i++) 
		    {
				rows.set(i, rows.get(i).toUpperCase());
			}

		    FileWriter writer = new FileWriter("employeedata.txt");
		    for(String cur: rows)
		        writer.write(cur+"\n");

		    reader.close();
		    writer.close();
	}
}
