
public class MyRecursiveBinarySearch
{
	public static int recursiveBinarySearch(int[] sortedArray, int start, int end, int key) 
	{
		if(start<end)
		{

			int m = (start+end)/2;
			if(key>sortedArray[m])
			{
				return recursiveBinarySearch(sortedArray, m+1, end, key);
			}
			else if(key<sortedArray[m])
			{
				return recursiveBinarySearch(sortedArray, start, m-1, key);
			}else
				{
					return m;
				}
		}
		else
		{
			return -1;
		}
	}
	public static void main(String[] args) 
	{
		int[] arr1 = {2,45,234,567,876,900,976,999};
		int index = recursiveBinarySearch(arr1,0,arr1.length,45);
		System.out.println("Found 45 at "+index+" index");
		index = recursiveBinarySearch(arr1,0,arr1.length,999);
		System.out.println("Found 999 at "+index+" index");
		index = recursiveBinarySearch(arr1,0,arr1.length,876);
		System.out.println("Found 876 at "+index+" index");
	}
}
