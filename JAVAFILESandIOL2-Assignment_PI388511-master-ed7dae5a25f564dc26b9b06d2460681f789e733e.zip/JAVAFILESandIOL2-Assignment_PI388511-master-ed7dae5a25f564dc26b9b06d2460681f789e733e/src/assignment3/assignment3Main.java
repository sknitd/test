//Write a program to encrypt/decrypt a file using: 
//(1)An offset cipher: static function offsetCipher offsets using 3 shifts
//(2)A substitution cipher: static function substitutionCipher substitutes normal alphabetic sequence into qwerty sequency(can also be replaced with symbols or numbers)
package assignment3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class assignment3Main
{
	public static String offsetCipher(String str,int shift)
	{
		String lowerString ="abcdefghijklmnopqrstuvwxyz";
		String upperString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int offset=0;
	    int newOffset=0;
	    String alpha;
	    StringBuffer sb = new StringBuffer();
	    for(int i=0;i<str.length();i++)
	    {
	        if(str.charAt(i)==' ')
	        {
	        	sb.append(' ');
	        }
	        else
	        {
	        	String temp = "" + str.charAt(i);
		        if(Character.isLowerCase(str.charAt(i)))
		        {
		        	alpha=lowerString;
		        }
		        else
		        {
		        	alpha=upperString;
		        }
		        offset = alpha.indexOf(temp);
		        offset += shift;
		        if(offset > 25)
		        {
		            newOffset = offset % 26;
		            sb.append(alpha.charAt(newOffset));
		        }
		        else
		        {
		            sb.append(alpha.charAt(offset));
		        }
	        }
	    }
			
		return sb.toString();
	}
	
public static String substitutionCipher	(String str)
{
	String lowerString ="abcdefghijklmnopqrstuvwxyz";
	String upperString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	String lowerKey="qwertyuiopasdfghjklzxcvbnm";
	String upperKey="QWERTYUIOPASDFGHJKLZXCVBNM";
    String alpha,key;
    int index;
    StringBuffer sb = new StringBuffer();
    for(int i=0;i<str.length();i++)
    {
        if(str.charAt(i)==' ')
        {
        	sb.append(' ');
        }
        else
        {
        	String temp = "" + str.charAt(i);
	        if(Character.isLowerCase(str.charAt(i)))
	        {
	        	alpha=lowerString;
	        	key=lowerKey;
	        }
	        else
	        {
	        	alpha=upperString;
	        	key=upperKey;
	        }
	        index=alpha.indexOf(temp);
	        sb.append(key.charAt(index));
	        
	        
	       
        }
    }
	return sb.toString();
}
	
	
	
	
	public static void main(String[] args) throws IOException
	{
		 ArrayList<String> rows = new ArrayList<String>();
		 ArrayList<String> enc1 = new ArrayList<String>();
		 ArrayList<String> enc2 = new ArrayList<String>();
		    BufferedReader reader = new BufferedReader(new FileReader("raw.txt"));

		    String s;
		    while((s = reader.readLine())!=null)
		        rows.add(s);

		    for (int i =0;i<rows.size();i++)
		    {
				enc1.add(i, offsetCipher(rows.get(i), 5)); // 5 shifts are used
				enc2.add(i, substitutionCipher(rows.get(i)));
			}

		    FileWriter writer = new FileWriter("encryptedoffset.txt");
		    for(String cur: enc1)
		        {writer.write(cur+"\n");}
		    writer.close();
		    
		    FileWriter writer2 = new FileWriter("encryptedsub.txt");
		    for(String cur: enc2)
		        {writer2.write(cur+"\n");}

		    reader.close();
		    writer2.close();
	}

}
